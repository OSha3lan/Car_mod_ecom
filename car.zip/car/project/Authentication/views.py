from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.http import JsonResponse
from django.views import View
from django.contrib.auth.models import User

class RegisterView(View):
    def post(self, request):
        data = request.POST
        user = User.objects.create_user(username=data['email'], email=data['email'], password=data['password'])
        return JsonResponse({'message': 'User registered successfully'}, status=201)

class LoginView(View):
    def post(self, request):
        data = request.POST
        user = authenticate(username=data['email'], password=data['password'])
        if user:
            login(request, user)
            return JsonResponse({'message': 'Login successful'})
        return JsonResponse({'error': 'Invalid credentials'}, status=400)

